Requirements:
* Python 3
* itertools module

Files:
* seq_1.txt has coding sequences of S.cerevisiae
* sequence.fasta has all the nucleotides for the entire genome (mitochondrial)

